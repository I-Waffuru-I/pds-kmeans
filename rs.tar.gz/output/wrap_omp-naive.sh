#!/usr/bin/env bash
exec "/vsc-hard-mounts/leuven-user/393/vsc39345/pds/kmeans_omp/build/bin/kmeans_omp" "$@" --mode omp-naive
